
import "./App.css";
import { UserRoutes } from "./routes/user.routes";

function App() {
  return (
    <div className="App">
      <UserRoutes />
    </div>
  );
}

export default App;
